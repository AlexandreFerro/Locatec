# 2021_Grupo-2_Locatec
 PI_6-Semestre


## Plataforma web para gerenciamento de locação de veículos.

### Projeto em desenvolvimento pelo grupo:

* Alexandre Ferro
* Ana Paula
* Murilo Rigão
* Sidnei Souza

_